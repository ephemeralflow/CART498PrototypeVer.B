screen player_card(player_name):
    python:
        everyone_ready = all(p["players_ready"] for p in players.values())
        # current_loc = players[player_name]["location"]
        is_showing_map = players[player_name]["showing_map"]
        is_revealed = p_data.get("roles_revealed", False)
        text_shown = p_data.get("role_text_shown", False)
        my_role = players[player_name]["role"]
        is_my_master = players[player_name].get("is_master", False)
        target_to_confirm = players[player_name].get("converting_target", None)

        my_exile_target = players[player_name].get("exile_target", None)
        my_exile_confirmed = players[player_name].get("exile_confirmed", False)
        
        active_players = [p for p in players.values() if p["role"] != "Exiled"]
        all_exiles_voted = bool(active_players) and all(p["exile_confirmed"] for p in active_players)

        is_this_minigame_active = vampire_minigame_active and (vampire_attacker == player_name)
        is_player_exiled = (my_role == "Exiled")

        is_shaking = p_data.get("card_shaking", False) # Tracking state for the shake animation

        marker_chosen = p_data.get("marker_choice") is not None

        p_data = players.get(player_name, {})
        current_loc = p_data.get("location", "Main Hub")
        
        # Check if every player has pressed to join the ball / readied up
        everyone_joined_ball = all(p.get("players_ready", False) for p in players.values())

        bg_color = "#16151a"

        # ==========================================
        # DYNAMIC ROOM BACKGROUND LOGIC
        # ==========================================
        if exile_phase_active or exile_results_active:
            # Hide map backgrounds and revert to unified dark color during Exile
            bg_image = None
            active_bg_color = "#16151a"
        elif everyone_joined_ball and map_controls_unlocked:
            # During map exploration, show room backgrounds based on current location
            if current_loc == "Main Hub":
                bg_image = "map_main_hub.png"
            elif current_loc == "Left Wing":
                bg_image = "map_wing_left.png"
            elif current_loc == "Right Wing":
                bg_image = "map_wing_right.png"
            elif current_loc == "Balcony":
                bg_image = "map_balcony.png"
            else:
                bg_image = "map_main_hub.png"
            active_bg_color = None
        else:
            # Default pre-game state
            bg_image = None
            active_bg_color = None

        p_data = players.get(player_name, {})
        my_role = p_data.get("role", "Host")
        is_master = p_data.get("is_master", False)
        is_ready = p_data.get("players_ready", False)

        current_phase = p_data.get("menu_phase", "initial")
        
        # Check if ALL players have pressed ready in this pre-game lobby
        all_players_code_ready = all(p.get("menu_phase") == "ready_wait" for p in players.values())
        
        if my_role == "Vampire" and is_master:
            role_display_text = "Master Vampire"
            role_color = "#de2f2f"
            role_desc = "You're a noble who hides a dark secret...\n\nConquer the night, and grow your army."
        elif my_role == "Vampire":
            role_display_text = "Vampire"
            role_color = "#de2f2f"
            role_desc = "Lorem Ipsum."
        elif my_role == "Priest":
            role_display_text = "Priest"
            role_color = "#de2f2f"
            role_desc = "An anonymous tip led you here...\n\nProtect the innocent and exorcise all evil."
        elif my_role == "Cultist":
            role_display_text = "Cultist"
            role_color = "#de2f2f"
            role_desc = "You've heard your master is here...\n\nNo one knows character better than you."
        elif my_role == "Exiled":
            role_display_text = "Exiled"
            role_color = "#aeaeae"
            role_desc = "Lorem Ipsum."
        else:
            role_display_text = "Host"
            role_color = "#de2f2f"
            role_desc = "You've invited people from all around for a night to remember...\n\nOnly you know your manor best."
            

    frame:
        xfill True
        yfill True
        padding (20, 20)
        background active_bg_color  # Falls back to "#16151a" during exile, or None during exploration

        # Display the room background image only if bg_image is active
        if bg_image:
            add bg_image xysize (600,300) xalign 0.5 yalign 0.5

        if is_shaking:
            at shake_effect

        # ==========================================
        # PHASE 0A: INITIAL SCREEN (Join Game / Host Game)
        # ==========================================
        if current_phase == "initial":
            vbox:
                xalign 0.5
                yalign 0.5
                spacing 20

                text "[player_name]" size 20 color "#fff" bold True xalign 0.5

                # Join Game Button -> Changes phase to code_entry and generates random code
                textbutton "Join Game":
                    action [
                        SetDict(players[player_name], "menu_phase", "code_entry"),
                        SetDict(players[player_name], "game_code", generate_random_code())
                    ]
                    padding (16, 10)
                    background "#8b0000"
                    hover_background "#de2f2f"
                    text_size 16
                    text_color "#fff"
                    xalign 0.5

                # Host Game Button -> Greyed out and unclickable (Null action)
                textbutton "Host Game":
                    action None
                    padding (16, 10)
                    background "#444444"
                    text_size 16
                    text_color "#aeaeae"
                    xalign 0.5

        # ==========================================
        # PHASE 0B: CODE ENTRY SCREEN
        # ==========================================
        elif current_phase == "code_entry":
            vbox:
                xalign 0.5
                yalign 0.5
                spacing 15

                text "Insert Code Here" size 18 color "#fff" bold True xalign 0.5

                # Display the single shared code with an underline using {u} tags
                text "{u}[game_code]{/u}" size 28 color "#de2f2f" bold True xalign 0.5

                null height 10

                # Ready Button -> Moves them to the waiting state
                textbutton "Ready":
                    action SetDict(players[player_name], "menu_phase", "ready_wait")
                    padding (14, 8)
                    background "#8b0000"
                    hover_background "#de2f2f"
                    text_size 16
                    text_color "#fff"
                    xalign 0.5

        # ==========================================
        # PHASE 0C: WAITING FOR ALL PLAYERS
        # ==========================================
        elif current_phase == "ready_wait" and not all_players_code_ready:
            vbox:
                xalign 0.5
                yalign 0.5
                spacing 10

                text "Waiting for other players to press ready..." size 16 color "#aaa" xalign 0.5 text_align 0.5

        # ==========================================
        # EXISTING PHASES (Marker Selection & Beyond)
        # ==========================================
        else:
            # (Your existing code starting with 'if not marker_chosen:' goes right here!)
            # Once all_players_code_ready is True, it automatically bypasses this wait 
            # and drops straight into your Phase 1: Marker Choice screen seamlessly!

            # ==========================================
            # PHASE 1: MARKER CHOICE (Appears first)
            # ==========================================
            if not marker_chosen:
                fixed:
                    xfill True
                    yfill True

                    text "Choose Your Marker Style:" size 16 color "#fff" bold True xalign 0.5 ypos 80

                    imagebutton:
                        idle "redspace1.png"
                        hover "redspace1.png"
                        xysize (60, 60)
                        xpos 220
                        ypos 150
                        action SetDict(players[player_name], "marker_choice", "style1")

                    imagebutton:
                        idle "coconut.png"
                        hover "coconut.png"
                        xysize (60, 60)
                        xpos 360
                        ypos 150
                        action SetDict(players[player_name], "marker_choice", "style2")

                    imagebutton:
                        idle "greenspace.png"
                        hover "greenspace.png"
                        xysize (60, 60)
                        xpos 220
                        ypos 240
                        action SetDict(players[player_name], "marker_choice", "style3")

                    imagebutton:
                        idle "bluespace.png"
                        hover "bluespace.png"
                        xysize (60, 60)
                        xpos 360
                        ypos 240
                        action SetDict(players[player_name], "marker_choice", "style4")

            # ==========================================
            # PHASE 2: LETTER & ROLE REVEAL (Appears AFTER marker is chosen)
            # ==========================================

            else: 
                if not is_revealed:
                    add "cards.png":
                        xysize (600, 300)  # <-- Replace with your exact desired (width, height) in pixels
                        align (0.5, 0.5)
                else:
                    add "cards1.png":
                        xysize (600, 300)  # <-- Replace with your exact desired (width, height) in pixels
                        align (0.5, 0.5)
                    at smooth_fade_in
            
                vbox:
                    xfill True
                    yfill True

                    null height 5
                    # ==========================================
                    # 0. TOP PRIORITY: GAME OVER / VICTORY SCREEN
                    # ==========================================
                    if game_over_state == "vampire_win":
                        frame:
                            xfill True
                            yfill True
                            background "#110000ee"
                            
                            vbox:
                                xalign 0.5
                                yalign 0.5
                                spacing 20
                                
                                text "VAMPIRES WIN!" size 32 color "#de2f2f" bold True xalign 0.5 text_align 0.5
                                text "All surviving players are now vampires. There are only vampires left." size 16 color "#de2f2f" xalign 0.5 text_align 0.5
                                
                                null height 10
                                
                                textbutton "Play Again":
                                    action Function(restart_game_loop)
                                    xalign 0.5
                                    padding (16, 10)
                                    background "#8b0000"
                                    hover_background "#de2f2f"
                                    text_size 16
                                    text_color "#fff"

                    elif game_over_state == "hunters_win":
                        frame:
                            xfill True
                            yfill True
                            background "#7d632e"
                            
                            vbox:
                                xalign 0.5
                                yalign 0.5
                                spacing 20
                                
                                text "SURVIVORS WIN!" size 32 color "#fff" bold True xalign 0.5 text_align 0.5
                                text "All vampires have been successfully cast out of the manor." size 16 color "#fff" xalign 0.5 text_align 0.5
                                
                                null height 10
                                
                                textbutton "Play Again":
                                    action Function(restart_game_loop)
                                    xalign 0.5
                                    padding (16, 10)
                                    background "#8b0000"
                                    hover_background "#de2f2f"
                                    text_size 16
                                    text_color "#fff"

                    # ==========================================
                    # 1. VAMPIRE MINIGAME ACTIVE PHASE
                    # ==========================================
                    elif is_this_minigame_active:
                        fixed:
                            xfill True
                            yfill True
                            
                            vbox:
                                xalign 0.5
                                yalign 0.15
                                spacing 5
                                text "BITE IN PROGRESS!" size 20 color "#de2f2f" bold True xalign 0.5 text_align 0.5
                                text "Click the appearing buttons ([vampire_step]/3)!" size 14 color "#fff" xalign 0.5

                            textbutton "BITE!":
                                action Function(handle_vampire_sequence_click)
                                xalign current_btn_pos[0]
                                yalign current_btn_pos[1]
                                padding (16, 12)
                                background "#8b0000"
                                hover_background "#de2f2f"
                                text_size 16
                                text_color "#fff"

                            timer 2.5 action Function(vampire_minigame_fail)

                    # ==========================================
                    # 1B. PRIEST MINIGAME ACTIVE PHASE
                    # ==========================================
                    elif priest_minigame_active and player_name == priest_attacker:
                        fixed:
                            xfill True
                            yfill True
                            
                            vbox:
                                xalign 0.5
                                yalign 0.15
                                spacing 5
                                text "EXORCISM IN PROGRESS!" size 20 color "#7d632e" bold True xalign 0.5 text_align 0.5
                                text "Click the appearing buttons ([priest_step]/3)!" size 14 color "#fff" xalign 0.5

                            textbutton "EXORCISE!":
                                action Function(handle_exorcism_sequence_click)
                                xalign priest_btn_pos[0]
                                yalign priest_btn_pos[1]
                                padding (16, 12)
                                background "#1e3fae"
                                hover_background "#7d632e"
                                text_size 16
                                text_color "#fff"

                            timer 2.5 action Function(exorcism_minigame_fail)

                    # ==========================================
                    # 2. EXILED ELIMINATION SCREEN STATE
                    # ==========================================
                    elif is_player_exiled:
                        vbox:
                            xalign 0.5
                            yalign 0.5
                            spacing 10
                            text "[player_name]" size 24 color "#aeaeae" xalign 0.5
                            text "EXILED" size 28 color "#de2f2f" bold True xalign 0.5 text_align 0.5
                            text "You have been cast out of the manor." size 14 color "#aaa" xalign 0.5 text_align 0.5

                    # ==========================================
                    # 3. EXILE RESULTS SCREEN
                    # ==========================================
                    elif exile_results_active:
                        python:
                            if exiled_player_result and exiled_player_result != "None" and exiled_player_result in players:
                                exiled_choice = players[exiled_player_result].get("marker_choice", "style1")
                                player_key_clean = exiled_player_result.lower().replace(" ", "")
                                exiled_image = f"{exiled_choice}_{player_key_clean}.png"
                            else:
                                exiled_image = ""

                        fixed:
                            xfill True
                            yfill True
                            
                            vbox:
                                at smooth_fade_in
                                xalign 0.5
                                yalign 0.5
                                spacing 15
                                
                                if exiled_player_result == "None" or exiled_player_result not in players:
                                    text "The votes were split or tied." size 20 color "#7d632e" bold True xalign 0.5 text_align 0.5
                                    text "No one was exiled today." size 18 color "#ffffff" xalign 0.5 text_align 0.5
                                else:
                                    # Displays the correct lowercase style image for the exiled player
                                    add exiled_image xysize (50, 50) xalign 0.5
                                    
                                    text "[exiled_player_result] has been exiled!" size 20 color "#de2f2f" bold True xalign 0.5 text_align 0.5
                                    
                                    if players[exiled_player_result].get("is_master", False):
                                        text "A vampire got exiled!" size 22 color "#de2f2f" bold True xalign 0.5 text_align 0.5
                                    elif players[exiled_player_result]["role"] == "Vampire":
                                        text "They were a Vampire!" size 22 color "#de2f2f" bold True xalign 0.5 text_align 0.5
                                    else:
                                        text "They were innocent." size 22 color "#fff" bold True xalign 0.5 text_align 0.5

                                if successfully_exorcised_player and player_name == successfully_exorcised_player:
                                    null height 10
                                    text "You were exorcised overnight and regained your purity." size 16 color "#7d632e" italic True xalign 0.5 text_align 0.5
                        timer 4.0 action [
                            Function(handle_exile_result_cleanup),
                            With(dissolve)
                        ]
                        
                    # ==========================================
                    # 4. PRIVATE EXILE SELECTION PHASE
                    # ==========================================
                    elif exile_phase_active and not exile_results_active:
                        if all_exiles_voted:
                            timer 0.1 action Function(process_exile_votes)

                        fixed:
                            xfill True
                            yfill True
                            
                            if my_exile_confirmed:
                                vbox:
                                    at smooth_fade_in
                                    xalign 0.5
                                    yalign 0.5
                                    spacing 10
                                    if my_exile_target and my_exile_target != "None":
                                        text "Vote Cast: Exile [my_exile_target]" size 18 color "#de2f2f" bold True xalign 0.5 text_align 0.5
                                    else:
                                        text "Vote Cast: Vote for No One" size 18 color "#de2f2f" bold True xalign 0.5 text_align 0.5
                                    text "Waiting for other players to vote..." size 14 color "#aaa" xalign 0.5 text_align 0.5
                            else:
                                vbox:
                                    at smooth_fade_in
                                    xalign 0.5
                                    yalign 0.2
                                    spacing 12
                                    text "Choose a Player to Exile" size 22 color "#de2f2f" bold True xalign 0.5 text_align 0.5
                                    
                                    null height 5

                                    for p_key, p_data in players.items():
                                        if p_data["role"] != "Exiled" and p_key != player_name:
                                            hbox:
                                                xalign 0.5
                                                spacing 20
                                                text "[p_key]" size 18 color "#ffffff" yalign 0.5
                                                
                                                textbutton "Exile":
                                                    action SetDict(players[player_name], "exile_target", p_key)
                                                    padding (8, 4)
                                                    background "#8b0000"
                                                    hover_background "#de2f2f"
                                                    text_size 14
                                                    text_color "#fff"

                                    null height 10

                                    textbutton "Vote for No One":
                                        action SetDict(players[player_name], "exile_target", "None")
                                        padding (12, 6)
                                        background "#444"
                                        hover_background "#666"
                                        text_size 14
                                        text_color "#fff"
                                        xalign 0.5

                                if my_exile_target:
                                    frame:
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 170
                                        background "#111111ea"
                                        padding (20, 20)
                                        
                                        vbox:
                                            xalign 0.5
                                            yalign 0.5
                                            spacing 15
                                            
                                            if my_exile_target == "None":
                                                text "Confirm Vote: No One?" size 16 color "#de2f2f" bold True xalign 0.5 text_align 0.5
                                            else:
                                                text "Confirm Exile Vote: [my_exile_target]?" size 16 color "#de2f2f" bold True xalign 0.5 text_align 0.5
                                            
                                            hbox:
                                                xalign 0.5
                                                spacing 20
                                                
                                                textbutton "Yes":
                                                    action SetDict(players[player_name], "exile_confirmed", True)
                                                    padding (12, 6)
                                                    background "#8b0000"
                                                    hover_background "#de2f2f"
                                                    text_size 14
                                                    text_color "#fff"
                                                    
                                                textbutton "Cancel":
                                                    action SetDict(players[player_name], "exile_target", None)
                                                    padding (12, 6)
                                                    background "#444"
                                                    hover_background "#666"
                                                    text_size 14
                                                    text_color "#fff"

                    # ==========================================
                    # 5. RESULT PHASE & POST-NIGHT DIALOGUE
                    # ==========================================
                    elif bite_result is not None:
                        fixed:
                            xfill True
                            yfill True

                            # 1. Initial outcome message (Appears alone in the dead center when step is 0)
                            if night_phase_step == 0:
                                vbox:
                                    at smooth_fade_in
                                    xalign 0.5
                                    yalign 0.5
                                    spacing 20
                                    if bite_result == "failure":
                                        text "No one was turned in the night." size 20 color "#ff5555" bold True xalign 0.5 text_align 0.5
                                    elif bite_result == "protected":
                                        text "A target was attacked, but miraculously protected last night!" size 18 color "#7d632e" bold True xalign 0.5 text_align 0.5
                                    elif bite_result == "success":
                                        text "There was a scream!\n\nSomeone must have been turned\nduring the night..." size 20 color "#de2f2f" bold True xalign 0.5 text_align 0.5

                            # 2. Discussion lines (Fixed positions once step >= 1)
                            elif night_phase_step >= 1:
                                vbox:
                                    at smooth_fade_in
                                    xalign 0.5
                                    yalign 0.45  # Fixed vertical anchor slightly above center
                                    spacing 15   # Consistent gap

                                    # Second line (always visible when step >= 1)
                                    text "There must be a vampire among us..." size 18 color "#ffffff" italic True xalign 0.5 text_align 0.5

                                    # Third line (appears when step >= 2, with an invisible placeholder when step == 1 so the second line never moves)
                                    if night_phase_step >= 2:
                                        text "Perhaps there should be an exile." size 18 color "#de2f2f" italic True xalign 0.5 text_align 0.5
                                    else:
                                        null height 22  # Matches the height of the third line text so layout doesn't shift when it appears

                        # Timers to progress the dialogue lines automatically with dissolves
                        if night_phase_step == 0:
                            timer 2.0 action [SetVariable("night_phase_step", 1), With(dissolve)]
                        elif night_phase_step == 1:
                            timer 2.0 action [SetVariable("night_phase_step", 2), With(dissolve)]
                        elif night_phase_step == 2:
                            timer 2.5 action [SetVariable("night_phase_step", 3), With(dissolve)]
                        elif night_phase_step >= 3:
                            timer 0.1 action [SetVariable("exile_phase_active", True), With(dissolve)]

                    # ==========================================
                    # 6. MOVEMENT & ROOM SELECTION CONTROLS
                    # ==========================================
                    elif map_controls_unlocked:
                        python:
                            is_locked = players[player_name].get("room_locked", False)
                            target_to_confirm = players[player_name].get("converting_target", None)
                            my_confirm_target = players[player_name].get("vampire_target_to_confirm", None)
                            has_bitten = players[player_name].get("has_bitten_this_night", False)

                        fixed:
                            xfill True
                            yfill True

                            vbox:
                                xalign 0.05
                                yalign 0.05
                                spacing 2
                                text "Current Room:" size 12 color "#aaa" xalign 0.0
                                text "[current_loc]" size 16 color "#de2f2f" bold True xalign 0.0

                            # ==========================================
                            # A1. AFTER LOCKING IN: Priest Action Menu & Exorcism Result
                            # ==========================================
                            if my_role == "Priest" and is_locked:
                                python:
                                    p_choice = players[player_name].get("priest_action_choice")
                                    p_target = players[player_name].get("priest_target")

                                vbox:
                                    xalign 0.5
                                    yalign 0.35
                                    spacing 15
                                    
                                    text "Room Locked: [current_loc]" size 18 color "#fff" bold True xalign 0.5 text_align 0.5

                                    # Show Exorcism Outcome during resolution phase
                                    if exorcism_result is not None:
                                        if priest_exorcism_success:
                                            text "EXORCISM SUCCESSFUL!" size 20 color "#7d632e" bold True xalign 0.5 text_align 0.5
                                            text "You successfully cleansed [priest_target] of the dark taint!" size 14 color "#fff" xalign 0.5 text_align 0.5
                                        else:
                                            text "EXORCISM FAILED!" size 20 color "#de2f2f" bold True xalign 0.5 text_align 0.5
                                            text "Your ritual failed to cleanse [priest_target]." size 14 color "#fff" xalign 0.5 text_align 0.5

                                        null height 10
                                        text "Waiting for the next round..." size 14 color "#aaa" xalign 0.5 text_align 0.5

                                    # If priest prepared an exorcism in the previous round, they can choose to exorcise now!
                                    elif priest_exorcism_ready and not p_choice:
                                        text "Divine Energy Ready: Exorcise a Vampire!" size 16 color "#7d632e" bold True xalign 0.5 text_align 0.5
                                        
                                        hbox:
                                            xalign 0.5
                                            spacing 20
                                            textbutton "Exorcise Target":
                                                action SetDict(players[player_name], "priest_action_choice", "exorcise")
                                                padding (10, 6)
                                                background "#1e3fae"
                                                text_size 14
                                                text_color "#fff"
                                                
                                            textbutton "Protect Instead / Decline":
                                                action SetDict(players[player_name], "priest_action_choice", "protect")
                                                padding (10, 6)
                                                background "#7d632e"
                                                text_size 14
                                                text_color "#fff"

                                    elif not p_choice:
                                        text "Choose Your Priest Night Action:" size 16 color "#de2f2f" bold True xalign 0.5 text_align 0.5
                                        
                                        hbox:
                                            xalign 0.5
                                            spacing 20
                                            textbutton "Protect Someone":
                                                action SetDict(players[player_name], "priest_action_choice", "protect")
                                                padding (10, 6)
                                                background "#7d632e"
                                                text_size 14
                                                text_color "#fff"
                                                
                                            textbutton "Pray (Prepare Exorcism for Next Round)":
                                                action Function(confirm_priest_prayer, player_name)
                                                padding (10, 6)
                                                background "#444"
                                                text_size 14
                                                text_color "#fff"
                                    
                                    elif p_choice == "protect":
                                        python:
                                            priest_confirmed = players[player_name].get("priest_confirmed", False)
                                            priest_confirm_target = players[player_name].get("priest_target_to_confirm", None)

                                        if priest_confirmed:
                                            vbox:
                                                xalign 0.5
                                                yalign 0.5
                                                spacing 10
                                                text "Action Confirmed: Protecting [p_target]" size 16 color "#fff" bold True xalign 0.5 text_align 0.5
                                                text "Waiting for other players to lock in..." size 14 color "#aaa" xalign 0.5 text_align 0.5
                                        else:
                                            fixed:
                                                xfill True
                                                yfill True
                                                
                                                # Main content underneath
                                                vbox:
                                                    xalign 0.5
                                                    yalign 0.35
                                                    spacing 10
                                                    
                                                    text "Action: Protect Player from Bite" size 14 color "#fff" bold True xalign 0.5
                                                    text "Select a player in this room to protect:" size 14 color "#fff" xalign 0.5
                                                    
                                                    python:
                                                        # Allows protecting anyone in the room, INCLUDING self (removed p_k != player_name)
                                                        same_room_targets = [
                                                            (p_k, p_d) for p_k, p_d in players.items() 
                                                            if p_d["location"] == current_loc 
                                                            and p_d["role"] != "Exiled"
                                                        ]

                                                    if not same_room_targets:
                                                        text "No other players in this room to protect." size 12 color "#888" xalign 0.5
                                                    else:
                                                        for p_key, p_data in same_room_targets:
                                                            hbox:
                                                                xalign 0.5
                                                                spacing 15
                                                                text "[p_key]" size 14 color "#fff" yalign 0.5
                                                                if p_target == p_key:
                                                                    text "✓ Selected" size 12 color "#fff" yalign 0.5
                                                                else:
                                                                    textbutton "Select":
                                                                        action SetDict(players[player_name], "priest_target_to_confirm", p_key)
                                                                        padding (6, 2)
                                                                        background "#8b0000"
                                                                        text_size 12

                                                    null height 10
                                                    textbutton "Reset Choice":
                                                        action [
                                                            SetDict(players[player_name], "priest_action_choice", None), 
                                                            SetDict(players[player_name], "priest_target", None),
                                                            SetDict(players[player_name], "priest_target_to_confirm", None),
                                                            SetDict(players[player_name], "priest_confirmed", False)
                                                        ]
                                                        xalign 0.5
                                                        padding (6, 4)
                                                        background "#444"
                                                        text_size 12

                                                # ==========================================
                                                # CENTERED POPUP OVERLAY IN THE MIDDLE
                                                # ==========================================
                                                if priest_confirm_target:
                                                    frame:
                                                        xalign 0.5
                                                        yalign 0.5
                                                        xsize 360
                                                        ysize 190
                                                        background "#18181ee8"
                                                        padding (20, 20)
                                                        
                                                        vbox:
                                                            xalign 0.5
                                                            yalign 0.5
                                                            spacing 20
                                                            
                                                            text "Are you sure you want to protect [priest_confirm_target]?" size 16 color "#fff" bold True xalign 0.5 text_align 0.5
                                                            
                                                            hbox:
                                                                xalign 0.5
                                                                spacing 30
                                                                
                                                                textbutton "Yes":
                                                                    action [
                                                                        SetDict(players[player_name], "priest_target", priest_confirm_target),
                                                                        SetDict(players[player_name], "priest_confirmed", True),
                                                                        SetDict(players[player_name], "priest_target_to_confirm", None),
                                                                        Function(lock_player_room, player_name)
                                                                    ]
                                                                    padding (14, 8)
                                                                    background "#8b0000"
                                                                    hover_background "#4caf50"
                                                                    text_size 14
                                                                    text_color "#fff"
                                                                    
                                                                textbutton "Cancel":
                                                                    action SetDict(players[player_name], "priest_target_to_confirm", None)
                                                                    padding (14, 8)
                                                                    background "#444"
                                                                    hover_background "#666"
                                                                    text_size 14
                                                                    text_color "#fff"

                                    elif p_choice == "exorcise":
                                        text "Action: Exorcise a Vampire" size 14 color "#1e3fae" bold True xalign 0.5
                                        text "Select a suspect in this room to exorcise:" size 14 color "#fff" xalign 0.5
                                        
                                        python:
                                            same_room_targets = [
                                                (p_k, p_d) for p_k, p_d in players.items() 
                                                if p_k != player_name 
                                                and p_d["location"] == current_loc 
                                                and p_d["role"] != "Exiled"
                                            ]
                                            target_to_confirm = players[player_name].get("priest_target", None)

                                        if not same_room_targets:
                                            text "No other players in this room to exorcise." size 12 color "#888" xalign 0.5
                                        else:
                                            for p_key, p_data in same_room_targets:
                                                hbox:
                                                    xalign 0.5
                                                    spacing 15
                                                    text "[p_key]" size 14 color "#fff" yalign 0.5
                                                    if target_to_confirm == p_key:
                                                        text "✓ Targeted" size 12 color "#1e3fae" yalign 0.5
                                                        textbutton "Clear":
                                                            action SetDict(players[player_name], "priest_target", None)
                                                            padding (4, 2)
                                                            background "#444"
                                                    else:
                                                        textbutton "Select Target":
                                                            action [
                                                                SetDict(players[player_name], "priest_target", p_key),
                                                                SetDict(players[player_name], "room_locked", True),
                                                                Function(start_exorcism_minigame, player_name, p_key)
                                                            ]
                                                            padding (6, 2)
                                                            background "#1e3fae"
                                                            text_size 12

                                        null height 10
                                        textbutton "Reset Choice":
                                            action [SetDict(players[player_name], "priest_action_choice", None), SetDict(players[player_name], "priest_target", None)]
                                            xalign 0.5
                                            padding (6, 4)
                                            background "#444"
                                            text_size 12

                            # ==========================================
                            # A2. AFTER LOCKING IN: Waiting Screen & Vampire Bite Menu
                            # ==========================================
                            elif is_locked or has_bitten:
                                if single_screen_mode and not (my_role == "Vampire" and is_my_master and not has_bitten):
                                    timer 2.5 action Function(resolve_night_phase)
                                vbox:
                                    xalign 0.5
                                    yalign 0.35
                                    spacing 15
                                    
                                    text "Room Locked: [current_loc]" size 18 color "#fff" bold True xalign 0.5 text_align 0.5

                                    # Master Vampire conversion menu appears ONLY after locking into the room!
                                    if my_role == "Vampire" and is_my_master and not has_bitten:
                                        text "Choose a Target to Bite (or Skip):" size 14 color "#de2f2f" xalign 0.5 text_align 0.5
                                        
                                        python:
                                            # STRICT RULE: Must share the same room AND also be locked into that room!
                                            same_room_targets = [
                                                (p_k, p_d) for p_k, p_d in players.items() 
                                                if p_k != player_name 
                                                and p_d["location"] == current_loc 
                                                and p_d.get("room_locked", False)
                                                and p_d["role"] != "Exiled" 
                                                and p_d["role"] != "Vampire"
                                            ]

                                        if not same_room_targets:
                                            text "No locked targets in this room to bite." size 12 color "#888" xalign 0.5
                                        else:
                                            for p_key, p_data in same_room_targets:
                                                hbox:
                                                    xalign 0.5
                                                    spacing 10
                                                    text "[p_key]" size 14 color "#fff" yalign 0.5
                                                    if target_to_confirm == p_key:
                                                        text "[Selected]" size 12 color "#de2f2f" yalign 0.5
                                                        textbutton "Clear":
                                                            action SetDict(players[player_name], "vampire_target_to_confirm", None)
                                                            padding (4, 2)
                                                            background "#444"
                                                            text_size 12
                                                    else:
                                                        textbutton "Select Target":
                                                            action SetDict(players[player_name], "vampire_target_to_confirm", p_key)
                                                            padding (6, 2)
                                                            background "#8b0000"
                                                            text_size 12

                                            null height 5
                                            if target_to_confirm == "Skip":
                                                text "[Bite Skipped]" size 12 color "#de2f2f" xalign 0.5
                                                textbutton "Undo Skip":
                                                    action SetDict(players[player_name], "vampire_target_to_confirm", None)
                                                    padding (4, 2)
                                                    background "#444"
                                                    text_size 12
                                            else:
                                                textbutton "Skip Bite (Turn No One)":
                                                    action SetDict(players[player_name], "vampire_target_to_confirm", "Skip")
                                                    padding (8, 4)
                                                    background "#444"
                                                    hover_background "#666"
                                                    text_size 12
                                                    text_color "#fff"
                                                    xalign 0.5

                                    if target_to_confirm and target_to_confirm != "Skip":
                                        text "Target Processed: [target_to_confirm]" size 14 color "#de2f2f" bold True xalign 0.5 text_align 0.5
                                    elif has_bitten:
                                        text "Bite Action Completed for Tonight." size 14 color "#de2f2f" bold True xalign 0.5 text_align 0.5

                                    null height 10
                                    text "Waiting for other players to lock in..." size 14 color "#aaa" xalign 0.5 text_align 0.5

                            # ==========================================
                            # B. BEFORE LOCKING IN: Map Movement & Lock Button
                            # ==========================================
                            else:
                                if current_loc != "Left Wing":
                                    textbutton "◄ Left Wing":
                                        action SetDict(players[player_name], "location", "Left Wing")
                                        xalign 0.05 
                                        yalign 0.5 
                                        padding (12, 16) 
                                        background "#333" 
                                        hover_background "#555" 
                                        text_size 16 
                                        text_color "#fff"

                                if current_loc != "Right Wing":
                                    textbutton "Right Wing ►":
                                        action SetDict(players[player_name], "location", "Right Wing")
                                        xalign 0.95 
                                        yalign 0.5 
                                        padding (12, 16) 
                                        background "#333" 
                                        hover_background "#555" 
                                        text_size 16 
                                        text_color "#fff"

                                if current_loc != "Balcony":
                                    textbutton "▲ Balcony":
                                        action SetDict(players[player_name], "location", "Balcony")
                                        xalign 0.5 
                                        yalign 0.25 
                                        padding (12, 8) 
                                        background "#333" 
                                        hover_background "#555" 
                                        text_size 16 
                                        text_color "#fff"

                                if current_loc != "Main Hub":
                                    textbutton "▼ Main Hub":
                                        action SetDict(players[player_name], "location", "Main Hub")
                                        xalign 0.5 
                                        yalign 0.75 
                                        padding (12, 8) 
                                        background "#333" 
                                        hover_background "#555" 
                                        text_size 16 
                                        text_color "#fff"

                                # Mandatory bottom button to lock in room choice
                                imagebutton:
                                    auto "button1_%s.png"
                                    xalign 0.5
                                    yalign 0.5
                                    action Function(lock_player_room, player_name)

                                textbutton "Stay in this Room & Lock In":
                                    action Function(lock_player_room, player_name)
                                    xalign 0.5
                                    yalign 0.5
                                    padding (16, 10)
                                    background None
                                    text_size 16
                                    text_color "#fff"

                            # ==========================================
                            # C. OVERLAY POPUP FOR VAMPIRE TARGET CONFIRMATION
                            # ==========================================
                            if my_confirm_target:
                                frame:
                                    xfill True
                                    yfill True
                                    background None
                                    frame:
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 360
                                        ysize 190
                                        background "#16151abf"
                                        padding (20, 20)
                                        vbox:
                                            xalign 0.5
                                            yalign 0.5
                                            spacing 20
                                            if my_confirm_target == "Skip":
                                                text "Are you sure you want to skip your bite tonight?" size 16 color "#de2f2f" bold True xalign 0.5 text_align 0.5
                                            else:
                                                text "Are you sure you want to turn [my_confirm_target]?" size 16 color "#de2f2f" bold True xalign 0.5 text_align 0.5
                                            hbox:
                                                xalign 0.5
                                                spacing 30
                                                textbutton "Yes":
                                                    action [
                                                        SetDict(players[player_name], "converting_target", my_confirm_target),
                                                        SetDict(players[player_name], "vampire_target_to_confirm", None),
                                                        SetDict(players[player_name], "room_locked", True),
                                                        Function(start_vampire_minigame, player_name, my_confirm_target) if my_confirm_target != "Skip" else [SetDict(players[player_name], "has_bitten_this_night", True), Function(check_round_completion)]
                                                    ]
                                                    padding (14, 8)
                                                    background "#8b0000"
                                                    text_size 14
                                                    text_color "#fff"
                                                textbutton "Cancel":
                                                    action SetDict(players[player_name], "vampire_target_to_confirm", None)
                                                    padding (14, 8)
                                                    background "#444"
                                                    text_size 14
                                                    text_color "#fff"

                    # ==========================================
                    # 7. ROLE REVIEW / READY PHASE
                    # ==========================================
                    elif everyone_ready and not map_controls_unlocked:
                            fixed:
                                vbox:
                                    xalign 0.5
                                    yalign 0.5
                                    text "Entering the ball...":
                                        size 20 
                                        color "#fff" 
                                        bold True 
                                        xalign 0.5 
                                        text_align 0.5
                    else:
                        
                            # SLOT 2: Role Title or Reveal Image Button
                            fixed:
                                xfill True
                                ysize 45
                                if is_revealed:
                                    text "[role_display_text]" size 22 color role_color bold True xalign 0.5 yalign 0.5 text_align 0.5
                                elif is_shaking:
                                    text "Unveiling..." size 16 color "#de2f2f" italic True xalign 0.5 yalign 0.5 text_align 0.5
                                    # Timer matches the shake duration (0.3s) before finishing the reveal and fading backgrounds
                                    timer 0.3 action [
                                        SetDict(players[player_name], "card_shaking", False),
                                        SetDict(players[player_name], "roles_revealed", True),
                                        Function(renpy.restart_interaction)
                                    ]
                                else:
                                    imagebutton:
                                        xalign 0.5
                                        ypos 50
                                        auto "waxSeal_%s.png"
                                        action [
                                            SetDict(players[player_name], "card_shaking", True),
                                            Function(renpy.restart_interaction)
                                        ]

                            # SLOT 3: Detailed Description or Loading Status (Fixed height: 45px)
                            fixed:
                                xfill True
                                ysize 45
                                if is_revealed:
                                    if not text_shown:
                                        timer 2.0 action SetDict(players[player_name], "role_text_shown", True)
                                        text "Consulting holy scripts..." size 13 color "#aaa" italic True xalign 0.5 yalign 0.3 text_align 0.5
                                    else:
                                        text "[role_desc]" size 13 color "#aeaeae" xalign 0.5 yalign 0.3 text_align 0.5

                            # SLOT 4: Ready Button or Waiting Text (Fixed height: 45px)
                            fixed:
                                xfill True
                                ysize 45
                                if text_shown and all_can_ready:
                                    if not is_ready:
                                        imagebutton:
                                            xalign 0.5
                                            yalign 1.0
                                            padding (12,6)
                                            auto "button_%s.png"

                                        textbutton "Join the ball...":
                                            xalign 0.5
                                            yalign 0.0
                                            padding (12, 6)
                                            background None
                                            text_color "#fff"
                                            text_size 15
                                            action SetDict(players[player_name], "players_ready", True)
                                    else:
                                        text "Waiting for other players..." size 15 color "#de2f2f" bold True xalign 0.5 yalign 0.5 text_align 0.5


                fixed:
                    xfill True
                    yfill True

                    # =========================================================
                    # MAP OVERLAY (Appears when the bottom-right button is toggled ON)
                    # =========================================================
                    if my_role not in ["Vampire", "Master Vampire", "Cultist", "Priest"] and is_showing_map and map_controls_unlocked:
                        frame:
                            xalign 0.5
                            yalign 0.45
                            xsize 320
                            ysize 260
                            background "#16151abf"
                            padding (20, 20)
                            
                            vbox:
                                xfill True
                                spacing 10
                                
                                text "Player Locations" size 18 color "#de2f2f" bold True xalign 0.5 text_align 0.5
                                null height 5
                                
                                for p_key, p_data_item in players.items():
                                    hbox:
                                        xfill True
                                        spacing 15
                                        text "[p_key]" size 14 color "#ffffff" bold True xalign 0.0 yalign 0.5
                                        text "[p_data_item['location']]" size 14 color "#aaaaaa" xalign 1.0 yalign 0.5

                    # ==========================================
                    # TOP-RIGHT ROLE DISPLAY HUD (Appears after clicking "I'm Ready")
                    # ==========================================
                    if is_ready:
                        python:
                            # Get the chosen style string (e.g., "style1", "style2", etc.)
                            my_marker_choice = p_data.get("marker_choice", "style1")
                            # Clean the player name to match lowercase filename formatting (e.g., "player4")
                            my_key_clean = player_name.lower().replace(" ", "")
                            # Build the exact icon filename
                            my_hud_icon = f"{my_marker_choice}_{my_key_clean}.png"

                        frame:
                            xalign 0.98
                            yalign 0.02
                            padding (10, 8)
                            background "#111111cc"
                            
                            vbox:
                                spacing 2
                                # text "[player_name]" size 12 color "#ffffff" bold True xalign 1.0
                                text "Role: [role_display_text]" size 14 color role_color bold True xalign 1.0

                        frame:
                            xalign 0.95
                            yalign 0.1
                            padding (10, 8)
                            background None
                            add my_hud_icon xysize (60,60) xalign 0.5


                    # =========================================================
                    # GUARANTEED HOST VIEW MAP BUTTON (Pinned directly to outer frame)
                    # =========================================================
                    if my_role not in ["Vampire", "Master Vampire", "Cultist", "Priest"] and map_controls_unlocked:
                        textbutton ("Back" if is_showing_map else "View Map"):
                            action ToggleDict(players[player_name], "showing_map")
                            xalign 0.98
                            yalign 0.98
                            padding (10, 6)
                            background "#222222cc"
                            hover_background "#444444cc"
                            text_size 12
                            text_color "#fff"